﻿using System;
using Nodos;
using listas;
using insertarnodo;

namespace menu
{


    class menuprincipal {

        static void Main(String[] args)
        {
            bool siguiente = true;
            Principal insertar = new Principal();

            while (siguiente)
                {

                Console.WriteLine( "\n "+  "Elige una opcion \n " + "1. insertar nodo \n" + "2. listar nodos \n" + "3. buscar nodos \n " + "4. Salir \n");
     

                int s1 = Convert.ToInt32(Console.ReadLine());

                 

                switch (s1)
                {
                    case 1:
                        insertar.Insertar();
                        break;


                    case 2:
                        insertar.Listar();  
                        break;

                    case 3:
                        insertar.Buscar();
                        break;

                    case 4:
                        siguiente = false;
                        Console.WriteLine("programa terminado");
                        break;

                    default:
                        siguiente = false;
                        break;
                }
            }
          
        }


    }



}

