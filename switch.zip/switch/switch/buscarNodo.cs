﻿using System;
using System.Collections.Generic;
using System.Text;
using Nodos;
using listas;

namespace buscarnodo
{
    class Buscar
    {

        private Nodo Primero = new Nodo();
        private Nodo Ultimo = new Nodo();

        public void BuscarNodo()
        {

            Nodo Actual = new Nodo();//Generar nuevo nodo para mostrar información en el.
            Actual = Primero;
            if (Primero != null)
            {
            /*  while (Actual != null)
              {
                  if (Actual.Dato == Nodo.Dato)
                  {
                        return (true);  // Búsqueda exitosa
                  }                     
                  else if (Nodo.Dato > Actual.Dato)
                    {
                        Actual = Actual.Siguiente; // Recorre el subárbol derecho
                    }                       
                   
                }
                return (false);  // No se encontró el nodo
                */
            }
            else
            {
                Console.Write("\n La lista no tiene nodos");
            }

        }





    }

      
}
