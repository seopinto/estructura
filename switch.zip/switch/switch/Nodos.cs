﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nodos
{
    class Nodo
    {
        //creación de los elementos de los nodos (Dato y siguente(apuntador o referencia))

        //Los nodos que se ingresarán son de tipo entero (int)
        private int dato;
        //Es el apuntador del nodo
        private Nodo siguiente;


        //Propiedades para los nodos
        public int Dato
        {
            get { return dato; }
            set { dato = value; }
        }

        public Nodo Siguiente
        {
            get { return siguiente; }
            set { siguiente = value; }
        }

    }
}
