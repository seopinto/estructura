﻿using System;
using System.Collections.Generic;
using System.Text;
using Nodos;
using buscarnodo;
namespace listas
{
    class Lista
    {
        private Nodo Primero = new Nodo();
        private Nodo Ultimo = new Nodo();

        public Lista()
        {
            Primero = null;
            Ultimo = null;
        }


        //Primero=10    //Ultimo=40         //Nuevo=40     (10,20,30,40)



        //Ingrese el dato que tendrá el nuevo Nodo: 10->20->30->40


        public void insertarNodo()
        {
            Nodo Nuevo = new Nodo();
            Console.Write("Ingrese el dato que tendrá el nuevo Nodo: ");
            Nuevo.Dato = int.Parse(Console.ReadLine());

            if (Primero == null)
            {
                Primero = Nuevo;
                Primero.Siguiente = null;
                Ultimo = Nuevo;
            }
            else
            {
                Ultimo.Siguiente = Nuevo;
                Nuevo.Siguiente = null;
                Ultimo = Nuevo;
            }
            Console.Write("Nodo ingresado correctamente\n\n ");
        }



        //Actual=10->20->30->40->null
        public void generarLista()
        {
            Nodo Actual = new Nodo();//Generar nuevo nodo para mostrar información en el.
            Actual = Primero;
            if (Primero != null)
            {
                while (Actual != null)
                {
                    Console.Write(" {0} ", Actual.Dato);
                    Actual = Actual.Siguiente;
                }
            }
            else
            {
                Console.Write("\n La lista no tiene nodos");
            }
        }

        public void BuscarNodo()
        {
            Nodo Actual = new Nodo();//Generar nuevo nodo para mostrar información en el.
            Console.Write("Ingrese el dato que deseas buscar: ");
            int valor = int.Parse(Console.ReadLine());

            Actual = Primero;
            if (Primero != null)
            {
                while (Actual != null)
                {
                    if (Actual.Dato == valor)
                    {
                        Console.Write("El dato ha sido encontrado {0} ", Actual.Dato);
                        Actual = Actual.Siguiente;
                    }
                    else 
                    {
                        Console.Write("\n La lista no tiene el nodo");
                        Actual = Actual.Siguiente;
                    }

                }
                
            }
            else
            {
                Console.Write("\n La lista no tiene nodos");
            }
        }
    }



}

