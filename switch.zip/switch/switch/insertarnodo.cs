﻿using System;
using Nodos;
using listas;

namespace insertarnodo
{
    class Principal
    {
        Lista lista1 = new Lista();
        public void Insertar()
        {            
            lista1.insertarNodo();          
            Console.WriteLine("\n La lista de los nodos ingresado es: ");
            lista1.generarLista();
            Console.ReadLine();

        }

        public void Listar()
        {
            Console.WriteLine("\n La lista de los nodos ingresado es: ");
            lista1.generarLista();
            Console.ReadLine();
        }

        public void Buscar()
        {
            lista1.BuscarNodo();
            Console.ReadLine();
        }
    }
}
